package com.example.weatherapp

data class Clouds(
    val all: Int
)