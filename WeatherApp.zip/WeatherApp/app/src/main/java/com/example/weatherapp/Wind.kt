package com.example.weatherapp

data class Wind(
    val deg: Int,
    val speed: Double
)